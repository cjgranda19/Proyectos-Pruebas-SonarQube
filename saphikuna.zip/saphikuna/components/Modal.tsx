// components/Modal.tsx
import React from "react";

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode; // Asegúrate de incluir children aquí
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, children }) => {
  if (!isOpen) return null;

  return (
   
  <div
  >
    {children}
    <div className="flex justify-center mt-4"> {/* Contenedor centrado */}
      <button
        className="bg-orange-500 text-white px-4 py-2 rounded"
        onClick={onClose}
      >
        Close
      </button>
    </div>
  </div>

  );
};

export default Modal;
