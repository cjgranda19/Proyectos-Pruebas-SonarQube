export type ResponseType = {
  result: any;
  loading: boolean;
  error: string;
};
