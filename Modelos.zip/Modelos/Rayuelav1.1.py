# Definir constantes para los textos repetidos
TEXTO_JUGADOR_TURNO = "Ingrese el jugador que jugara este turno"
TEXTO_OPCIONES_JUGADORES = "escoge a o 1 para: Jugador A o 1"
TEXTO_OPCIONES_JUGADOR_B = "escoge b o 2 para: Jugador B o 2"
TEXTO_SELECCIONE = "Seleccione: "
TEXTO_JUGADOR_NO_VALIDO = "Jugador no válido"

def escoger_jugador():
    # Realizamos el menu correspondiente a la cantidad de jugadores
    if(cantidad_jugadores == 2):
        # Presentamos los jugadores en juego
        print(TEXTO_JUGADOR_TURNO)
        print(TEXTO_OPCIONES_JUGADORES)
        print(TEXTO_OPCIONES_JUGADOR_B)
        # Ingresamos el jugador que juega primero
        jugador_escogido = input(TEXTO_SELECCIONE)
        # Comprobamos si el jugador está dentro del rango permitido
        if(jugador_escogido.lower() > 'b'):
            # Si el jugador no está dentro del rango se presenta el mensaje
            print(TEXTO_JUGADOR_NO_VALIDO)
            # Regresamos a la misma función
            return escoger_jugador()
    elif(cantidad_jugadores == 3):
        # Presentamos los jugadores en juego
        print(TEXTO_JUGADOR_TURNO)
        print(TEXTO_OPCIONES_JUGADORES)
        print("escoge c o 3 para: Jugador C o 3")
        # Ingresamos el jugador que juega primero
        jugador_escogido = input(TEXTO_SELECCIONE)
        # Comprobamos si el jugador está dentro del rango permitido
        if(jugador_escogido.lower() > 'c'):
            # Si el jugador no está dentro del rango se presenta el mensaje
            print(TEXTO_JUGADOR_NO_VALIDO)
            # Regresamos a la misma función
            return escoger_jugador()
    elif(cantidad_jugadores == 4):
        # Presentamos los jugadores en juego
        print(TEXTO_JUGADOR_TURNO)
        print(TEXTO_OPCIONES_JUGADORES)
        print("escoge c o 3 para: Jugador C o 3")
        print("escoge d o 4 para: Jugador D o 4")
        # Ingresamos el jugador que juega primero
        jugador_escogido = input(TEXTO_SELECCIONE)
        # Comprobamos si el jugador está dentro del rango permitido
        if(jugador_escogido.lower() > 'd'):
            # Si el jugador no está dentro del rango se presenta el mensaje
            print(TEXTO_JUGADOR_NO_VALIDO)
            # Regresamos a la misma función
            return escoger_jugador()

    return jugador_escogido

def rayuela():
    # Inicializamos a jugador con el jugador escogido
    jugador = escoger_jugador()
    # Imprimimos el jugador escogido
    print("jugador: " + jugador)
    
    # Damos las opciones a elegir al juez
    print("1: adentro")
    print("2: afuera")
    
    # Ingresamos en qué posición cayó la piedra, adentro que es 1 o afuera que es 2
    posicion = int(input("La piedra cayo adentro o afuera?  " '\n'))
    
    # Comparamos si la piedra cayó en la parte de afuera
    if posicion == 2:
        # Imprimimos el mensaje de que el jugador pierde el turno
        print("el jugador " + jugador + " perdió su turno")
        # Llamamos a la función escoger jugador y rayuela para hacer una repetición y seguir con otro jugador
        escoger_jugador()
        rayuela()
    
    # Comparamos si la piedra cayó en la parte de adentro
    if posicion == 1:
        # Imprimimos el mensaje de que el jugador puede seguir jugando hasta terminar el juego recogiendo la piedra que lanzó
        print("el jugador " + jugador + " sigue jugando y saltara hasta el final recogiendo su piedra")
        escoger_jugador()
        rayuela()
    
    # Retornamos el valor de posición 
    return posicion

def lee_entero():
    """
    En esta funcion se hacen las validaciones para poder escribir solo enteros al momento de ingresar el número de jugadores
    Parametros:
    -------------------
        enteros
    Retorna:
    -------------------
        cantidad_jugadores : int
            nos ayuda a saber el número de jugadores que se ingresaran.
    """
    # Hasta colocar la cantidad de jugadores válidos en números
    while True:
        # Comenzamos el juego
        print("\n<<<<<<<JUEGO TRADICIONAL LA RAYUELA>>>>>>>\n")
        # Repetimos el juego
        cantidad_jugadores = input("Escribe un numero entero del 2 al 4: ")
        try:
            cantidad_jugadores = int(cantidad_jugadores)
            return cantidad_jugadores
        except ValueError:
           print("La entrada es incorrecta escribe un numero entero")

# Función principal del juego
if __name__ == '__main__':
    # Declaramos una variable global
    cantidad_jugadores = lee_entero()
    # Comenzamos el juego
    print("\n<<<<<<<JUEGO TRADICIONAL LA RAYUELA>>>>>>>\n")
    # Si la cantidad de jugadores que el usuario desea crear está fuera del rango permitido, se repetirá el ingreso
    while(cantidad_jugadores > 4 or cantidad_jugadores < 2):
        # Presenta al usuario la cantidad de jugadores permitidos
        print("Jugadores permitidos de 2 a 4")
        # Ingreso de la cantidad de jugadores
        cantidad_jugadores = int(input("Ingrese la cantidad de jugadores: "))
        # Comparamos si los jugadores están entre 2 y 4
        if(cantidad_jugadores > 4 or cantidad_jugadores < 2):
            print("Cantidad de jugadores inválidos\n")
        else:
            rayuela()
