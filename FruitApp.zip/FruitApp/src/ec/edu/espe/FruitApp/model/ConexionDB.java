
package model;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

/**
 *
 * @author Carlos Granda,Jose Imbaquinga, Roony Ibarra, DCCO-ESPE, Syntax Error
 */
public class ConexionDB {
       public static MongoDatabase datos = null;

    public MongoDatabase conectionDb(){
       

        ConnectionString connectionString = new ConnectionString("mongodb+srv://CarlosGranda:");
        MongoClientSettings settings = MongoClientSettings.builder()
        .applyConnectionString(connectionString)
        .build();
        MongoClient mongoClient = MongoClients.create(settings);
        MongoDatabase fruteria = mongoClient.getDatabase("FruitDB");
       
                
    return database;
     }


}
