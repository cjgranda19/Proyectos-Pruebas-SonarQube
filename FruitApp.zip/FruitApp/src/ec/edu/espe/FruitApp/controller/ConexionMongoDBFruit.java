package controller;

import com.mongodb.client.MongoCollection;
import ec.edu.espe.FruitApp.model.ConexionDB;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author Carlos Granda,Jose Imbaquinga, Roony Ibarra, DCCO-ESPE, Syntax Error
 */
public class ConexionMongoDBFruit {
    public void ConexionFruit(String name, String texture, int quantity, double weight, float cost){
        MongoCollection<Document> FruitCollection = new ConexionDB().conectionDb().
                 getCollection("FruitCollection");
     Document data= new Document();  
     };  
    }
}

