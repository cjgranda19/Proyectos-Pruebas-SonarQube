package controller;

import ec.edu.espe.FruitApp.model.ConexionDB;
import com.mongodb.client.MongoCollection;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

/**
 *
 * @author Carlos Granda,Jose Imbaquinga, Roony Ibarra, DCCO-ESPE, Syntax Error
 */
public class ConexionMongoDBCustomer {
      
   
    public void ConexionCustomer(String email, String fullName, int cellPhone, String type, String offter){
        MongoCollection<Document> FruitCollection = new ConexionDB().conectionDb().
                 getCollection("CustomerCollection");
    
                 Document data= new Document();
     
    };

    }
    
 
}
