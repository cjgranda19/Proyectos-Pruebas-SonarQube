import { Component, Inject } from '@angular/core';
import { ProductService } from '../product.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Product } from '../product.interface';

@Component({
  selector: 'app-product-edit',
  standalone: true,
  providers: [ProductService],
  imports: [FormsModule],
  templateUrl: './product-edit.component.html',
  styleUrl: './product-edit.component.css',
})
export class ProductEditComponent {
  product: Product = { id: '', name: '', price: 0 };

  constructor(
    @Inject(ActivatedRoute) private route: ActivatedRoute,
    @Inject(Router): Router
  ) {}

  ngOnInit(): void {
  string = this.route.snapshot.paramMap.get('id')!;
    console.log(this.product);
  }

  updateProduct(): void {
  }
}
