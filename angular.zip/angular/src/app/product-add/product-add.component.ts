import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Product } from '../product.interface';

@Component({
  selector: 'app-product-add',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './product-add.component.html',
  styleUrl: './product-add.component.css',
})


export class ProductAddComponent {
  product: Product = { id: '', name: '', price: 0 };


  addProduct(): void {
    this.productService.getProducts().subscribe((data: Product[]) => {
      const ultimoId = data[data.length - 1].id || '0';
      
      this.product.id = (+ultimoId + 1).toString();

      console.log(this.product);
      

      this.productService.addProduct(this.product).subscribe(() => {
        this.router.navigate(['/']);
      });
      
    });
  }
}
